<?php
include "koneksi.php";

$q = "select * from mhs";
$ex = mysql_query($q);
echo "<a href='#' id='tambah-mhs'>Tambah MHS</a>";
echo "table border=1";
echo "<tr>
		<th>NPM</th>
		<th>Nama</th>
		<th>Alamat</th>
		<th>No Telepon</th>
		<th>Action</th>
	  </tr";

while($r = mysql_fetch_array($ex)){
	echo "<tr><td>".$r['npm']."</td>";
	echo "<td>".$r['nama']."</td>";
	echo "<td>".$r['alamat']."</td>";
	echo "<td>".$r['no_telp']."</td>";
	echo "<td><a href='#' id='ubah-mhs' x=' ".$r['npm']."'>Ubah</a>";
	echo "<a href='#' id='hapus-mhs' x='".$r['npm']."'>Hapus</a>";
	echo "</td></tr>";
}

echo "</table>";
?>

<script type="text/javascript">
$("ubah-mhs").click(function(){
	var x = $(this).attr("x");
	$.get("editmhs.php")
})
</script>