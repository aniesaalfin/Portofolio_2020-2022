<?php include "koneksi.php";
?>
	NPM : <input type="text" id="tnpm"/><br/>
	Nama : <input type="text" id="tnama"/><br/>
	Alamat : <input type="text" id="talamat"/><br/>
	No. Telepon : <input type="text" id="tnotelp"/><br/>
	<input type="submit" name="bok" value="simpan"/>

<?php
if(isset($_POST['op'])){
	$npm = $_POST['npm'];
	$nama = $_POST['nm'];
	$alamat = $_POST['alm'];
	$notelp = $_POST['telp'];
	$q = "insert into mhs(npm,nama,alamat,no_telp)";
	$q.=" values('$npm','$nama','$alamat','$notelp')";
	mysql_query($q);
}
?>

<script type="text/javascript">
	$(document).ready(function(){
		$("bok").click(function(){
			var x1 = $("#tnpm").val(),
				x2 = $("#tnama").val(),
				x3 = $("#talamat").val(),
				x4 = $("#tnotelp").val()

			$.post("addmhs.php",{op:"ok", npm:x1,nm:x2, alm:x3, telp:x4},function(){
				location.href = "tampilmhs.php";
			})
		})
	})
</script>