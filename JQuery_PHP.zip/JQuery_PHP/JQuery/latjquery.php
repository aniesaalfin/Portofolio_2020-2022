<!DOCTYPE html>
<html>
<head>
	<title>Coba JQuery</title>
	<script type="text/javascript" src="jquery-3.6.0.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#bok").click(function(){
				$.get("coba.txt",function(respon){
					$("#myDiv").html(respon);
				})
			})
		})
	</script>
</head>
<body>
	<div id="myDiv"><h2>Ajax akan merubah teks ini</h2></div>
	<input type="submit" value="Proses" id="bok"/>
	<div id="div-hasil"></div>
</body>
</html>