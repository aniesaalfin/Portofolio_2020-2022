<?php
$host = "localhost:8080";
$user = "root";
$pass = "";
$koneksi = mysqli_connect($host,$user,$pass);
mysqli_select_db("db_web2",$koneksi) or die(mysqli_error());
?>