<?php
include "koneksi.php";

$npm = $_GET['n'];
$q = "delete from mhs where npm='$npm'";

mysql_query($q);
echo "ok";
?>