<?php
include "koneksi.php";
$npm = $_GET['n'];
$q = "select * from mhs where npm='$npm'";
$ex = mysql_query($q);
$r = mysql_fetch_array($ex);
?>

<form action="#" method="post">
	NPM : <input type="text" name="tnpm" value="<?php echo $r['npm']; ?>"/><br/>
	Nama : <input type="text" name="tnama" value="<?php echo $r['nama']; ?>"/><br/>
	Alamat : <input type="text" name="talamat" value="<?php echo $r['alamat']; ?>"/><br/>
	No. Telepon : <input type="text" name="tnotelp" value="<?php echo $r['no_telp']; ?>"/><br/>
	<input type="submit" name="bok" value="Ubah data"/>
</form>

<a href="mhs.php">Kembali ...</a>

<?php
if(isset($_POST['bok'])){
	$npm = $_POST['tnpm'];
	$nama = $_POST['tnama'];
	$alamat = $_POST['talamat'];
	$notelp = $_POST['no_telp'];
	$q = "update mhs set nama='$nama', alamat='$alamat', no_telp='$notelp'";
	$q.= "where npm='$npm'";
	mysql_query($q);
	echo "Data berhasil diubah";
}
?>