<?php
include "koneksi.php";

$npm = $_GET['n'];
$q = "delete from mhs where npm='$npm'";

mysql_query($q);
echo "Data terhapus\n";
echo "<a href='mhs.php'>Kembali ... </a>";
?>