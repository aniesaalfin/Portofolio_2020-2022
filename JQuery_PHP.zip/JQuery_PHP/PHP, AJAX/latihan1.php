<!DOCTYPE html>
<html>
<head>
	<title>Mencoba PHP</title>
</head>
<body>
	Thomas: Hallo Putri, apa kabar..?
	<br>
	
	<?php
	echo "Putri: Kabar saya baik, Thoms.";
	?>

</body>
</html>