<!DOCTYPE html>
<html>
<head>
	<title>Mencoba PHP</title>
</head>
<body>
	<form action="#" method="get">
		Nama	: <input type="text" name="tname"><br/>
		Umur	: <input type="text" name="tumur"><br/>
		<input type="submit" name="bok" value="OK">
	</form>
	<?php
	if (isset($_GET ['bok'])){
		echo $_GET['tname']."<br/>";
		echo $_GET['tumur'];
	}
	?>

</body>
</html>