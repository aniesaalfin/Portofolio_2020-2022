<?php include "koneksi.php"; ?>
<form action="#" method="post">
	NPM : <input type="text" name="tnpm"/><br/>
	Nama : <input type="text" name="tnama"/><br/>
	Alamat : <input type="text" name="talamat"/><br/>
	No. Telepon : <input type="text" name="tnotelp"/><br/>
	<input type="submit" name="bok" value="simpan"/>
</form>

<a href="mhs.php">Kembali ... </a>

<?php
if(isset($_POST['bok'])){
	$npm = $_POST['tnpm'];
	$nama = $_POST['tnama'];
	$alamat = $_POST['talamat'];
	$notelp = $_POST['no_telp'];
	$q = "insert into mhs(npm,nama,alamat,no_telp)";
	$q.=" values('$npm','$nama','$alamat','$notelp')";
	mysql_query($q);
	echo "Data tersimpan";
}
?>