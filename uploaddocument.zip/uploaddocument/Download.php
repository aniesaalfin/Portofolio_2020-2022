<html> 
<title>Aplikasi Download</title> 
<body> 
<?php 
 $upload = mysqli_connect("localhost","root:8080","","uploaddocument"); 
 $query = "SELECT * FROM upload ORDER BY id_upload DESC";  $hasil = mysqli_query($upload, $query); 
 while ($r = mysqli_fetch_array($hasil)){ 
 echo "Nama File : <b>$r[nama_file]</b> <br>"; 
 echo "Deskripsi : $r[deskripsi] <br>"; 
 echo "<a href=\"donlot.php?file=$r[nama_file]\">Download File</a><hr><br>";  } 
?>
